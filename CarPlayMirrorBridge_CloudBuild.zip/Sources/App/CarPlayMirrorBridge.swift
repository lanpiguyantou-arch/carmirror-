//
//  CarPlayMirrorBridge.swift
//  CarPlayMirrorBridge v2.0 (自动旋转 + 智能全屏自适应 + 有线/无线自适应版)
//
//  适用场景：
//  1. 车型适配：2019款 雪佛兰科鲁泽 330T (1.3T) — 8英寸 MyLink+ 车载屏幕
//  2. 手机环境：iPhone 16e (iOS 26.6.1)
//
//  v2.0 升级亮点：
//  - 修复手机端全屏分辨率适配（消除上下黑边）与顶部标题重叠问题
//  - 新增【视频自动旋转纠正】：自动读取 ReplayKit 视频方向元数据与手机横竖屏状态，横屏看视频时自动摆正画面
//  - 新增【智能自适应车机屏幕】：当检测到横屏视频（宽 > 高）时自动铺满科鲁泽 8 英寸 16:9 屏幕，竖屏时自动等比居中，也支持强制横屏旋转 90°
//  - 新增【有线 / 无线传输模式自适应】：CarPlay 底层自动兼容有线 USB 与无线连接，并提供「有线高清 / 无线低延迟」动态画质调节
//

import UIKit
import CarPlay
import ReplayKit
import Network
import AVFoundation
import ImageIO

// MARK: - 0. 跨进程共享配置与显示模式枚举
enum MirrorSharedConfig {
    static let appGroupIdentifier = "group.com.monza.carplay.mirror"
    static let latestFrameFileName = "latest_screen_frame.jpg"
    static let settingsRotationKey = "mirror_rotation_mode"
    static let settingsLinkModeKey = "mirror_link_quality_mode"
    static let frameUpdatedNotification = "com.monza.carplay.mirror.frameUpdated" as CFString
    static let defaultHTTPPort: UInt16 = 8080

    static var sharedDefaults: UserDefaults? {
        UserDefaults(suiteName: appGroupIdentifier)
    }

    static var sharedFrameFileURL: URL? {
        FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier)?
            .appendingPathComponent(latestFrameFileName)
    }
}

/// 画面旋转与屏幕自适应模式
enum VideoRotationMode: Int {
    case autoSmart = 0       // 智能自动：根据视频/手机方向自动旋转，横屏视频自动铺满车机，竖屏等比显示
    case forceLandscape = 1  // 强制横屏旋转 90°：适合手机锁定竖屏但播放横屏视频时强制旋转铺满车机
    case forceFill = 2       // 强制铺满全屏：始终填满科鲁泽 8 英寸车机屏幕
}

/// 有线 / 无线传输画质优化模式
enum ConnectionQualityMode: Int {
    case autoWiredHD = 0     // 有线 CarPlay 高清模式（0.75 画质，适合 19款科鲁泽原车 USB 有线连接）
    case wirelessSmooth = 1  // 无线 CarPlay / 局域网流畅模式（0.50 画质，降低 Wi-Fi 带宽占用防卡顿）

    var jpegQuality: CGFloat {
        switch self {
        case .autoWiredHD: return 0.75
        case .wirelessSmooth: return 0.50
        }
    }
}

// MARK: - 1. 屏幕帧分发与智能旋转中心 (ScreenFrameHub)
final class ScreenFrameHub {
    static let shared = ScreenFrameHub()

    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    private let lock = NSLock()

    /// 供 CarPlay CPWindow 实时渲染的回调：(处理后的图像, 是否为横屏视频画面)
    var onFrameImageUpdate: ((UIImage, Bool) -> Void)?

    /// 供手机端界面监听 CarPlay 车机连接状态变化
    var onCarPlayConnectionChanged: ((Bool) -> Void)?

    /// 当前是否已连接 CarPlay 车机屏幕
    var isCarPlayConnected: Bool = false {
        didSet {
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.onCarPlayConnectionChanged?(self.isCarPlayConnected)
            }
        }
    }

    /// 当前旋转与自适应模式
    var rotationMode: VideoRotationMode = .autoSmart {
        didSet {
            MirrorSharedConfig.sharedDefaults?.set(rotationMode.rawValue, forKey: MirrorSharedConfig.settingsRotationKey)
        }
    }

    /// 当前有线/无线画质模式
    var qualityMode: ConnectionQualityMode = .autoWiredHD {
        didSet {
            MirrorSharedConfig.sharedDefaults?.set(qualityMode.rawValue, forKey: MirrorSharedConfig.settingsLinkModeKey)
        }
    }

    /// 最新的 JPEG 压缩帧数据
    private(set) var latestJPEGFrame: Data?

    private init() {
        if let savedRot = MirrorSharedConfig.sharedDefaults?.object(forKey: MirrorSharedConfig.settingsRotationKey) as? Int,
           let mode = VideoRotationMode(rawValue: savedRot) {
            rotationMode = mode
        }
        if let savedQual = MirrorSharedConfig.sharedDefaults?.object(forKey: MirrorSharedConfig.settingsLinkModeKey) as? Int,
           let qMode = ConnectionQualityMode(rawValue: savedQual) {
            qualityMode = qMode
        }
        registerForCrossProcessFrameNotifications()
    }

    private func registerForCrossProcessFrameNotifications() {
        let center = CFNotificationCenterGetDarwinNotifyCenter()
        let observer = Unmanaged.passUnretained(self).toOpaque()
        CFNotificationCenterAddObserver(
            center,
            observer,
            { _, observer, _, _, _ in
                guard let observer = observer else { return }
                let hub = Unmanaged<ScreenFrameHub>.fromOpaque(observer).takeUnretainedValue()
                hub.loadFrameFromAppGroup()
            },
            MirrorSharedConfig.frameUpdatedNotification,
            nil,
            .deliverImmediately
        )
    }

    private func loadFrameFromAppGroup() {
        guard let fileURL = MirrorSharedConfig.sharedFrameFileURL,
              let data = try? Data(contentsOf: fileURL),
              let image = UIImage(data: data) else { return }

        lock.lock()
        self.latestJPEGFrame = data
        lock.unlock()

        let isLandscapeFrame = image.size.width >= image.size.height
        DispatchQueue.main.async { [weak self] in
            self?.onFrameImageUpdate?(image, isLandscapeFrame)
        }
    }

    /// 处理 ReplayKit 视频帧：自动解析横竖屏方向元数据并执行 GPU 硬件旋转
    func processVideoSampleBuffer(_ sampleBuffer: CMSampleBuffer, writeToAppGroup: Bool = false) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        var ciImage = CIImage(cvPixelBuffer: pixelBuffer)

        // 1. 读取 ReplayKit 附带的屏幕方向元数据 (RPVideoSampleOrientationKey)
        if let orientationAttachment = CMGetAttachment(sampleBuffer, key: RPVideoSampleOrientationKey as CFString, attachmentModeOut: nil) as? NSNumber,
           let orientation = CGImagePropertyOrientation(rawValue: orientationAttachment.uint32Value) {
            ciImage = ciImage.oriented(orientation)
        }

        // 2. 读取用户设置的旋转模式（例如手机锁竖屏看视频时，强制旋转 90° 横屏）
        let currentRotMode: VideoRotationMode
        if writeToAppGroup,
           let raw = MirrorSharedConfig.sharedDefaults?.object(forKey: MirrorSharedConfig.settingsRotationKey) as? Int,
           let mode = VideoRotationMode(rawValue: raw) {
            currentRotMode = mode
        } else {
            currentRotMode = self.rotationMode
        }

        if currentRotMode == .forceLandscape && ciImage.extent.height > ciImage.extent.width {
            // 当画面为竖屏且开启了「强制横屏旋转」时，逆时针旋转 90 度以横屏显示在车机上
            ciImage = ciImage.oriented(.left)
        }

        let extent = ciImage.extent
        guard let cgImage = ciContext.createCGImage(ciImage, from: extent) else { return }
        let uiImage = UIImage(cgImage: cgImage)
        let isLandscapeFrame = extent.width >= extent.height

        // 3. 根据有线/无线模式动态调整 JPEG 压缩率
        let currentQuality: CGFloat
        if writeToAppGroup,
           let rawQ = MirrorSharedConfig.sharedDefaults?.object(forKey: MirrorSharedConfig.settingsLinkModeKey) as? Int,
           let qMode = ConnectionQualityMode(rawValue: rawQ) {
            currentQuality = qMode.jpegQuality
        } else {
            currentQuality = self.qualityMode.jpegQuality
        }

        guard let jpegData = uiImage.jpegData(compressionQuality: currentQuality) else { return }

        lock.lock()
        self.latestJPEGFrame = jpegData
        lock.unlock()

        if writeToAppGroup, let sharedURL = MirrorSharedConfig.sharedFrameFileURL {
            try? jpegData.write(to: sharedURL, options: .atomic)
            CFNotificationCenterPostNotification(
                CFNotificationCenterGetDarwinNotifyCenter(),
                CFNotificationName(MirrorSharedConfig.frameUpdatedNotification),
                nil,
                nil,
                true
            )
        } else {
            DispatchQueue.main.async { [weak self] in
                self?.onFrameImageUpdate?(uiImage, isLandscapeFrame)
            }
        }
    }
}

// MARK: - 2. 本地低延迟 MJPEG 投屏服务器 (Local Mirror Server)
final class LocalMJPEGServer {
    static let shared = LocalMJPEGServer()
    private var listener: NWListener?
    private var activeConnections: [NWConnection] = []
    private var streamTimer: Timer?
    private let queue = DispatchQueue(label: "com.monza.carplay.mjpegserver", qos: .userInteractive)

    private(set) var isRunning = false
    let port: UInt16 = MirrorSharedConfig.defaultHTTPPort

    func start() {
        guard !isRunning else { return }
        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            listener = try NWListener(using: params, on: NWEndpoint.Port(rawValue: port)!)
        } catch {
            return
        }

        listener?.newConnectionHandler = { [weak self] connection in
            self?.handleNewConnection(connection)
        }

        listener?.stateUpdateHandler = { [weak self] state in
            if case .ready = state {
                self?.isRunning = true
            }
        }

        listener?.start(queue: queue)

        DispatchQueue.main.async {
            self.streamTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
                self?.broadcastLatestFrame()
            }
        }
    }

    private func handleNewConnection(_ connection: NWConnection) {
        connection.start(queue: queue)
        let responseHeader = "HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=carplayframe\r\nCache-Control: no-cache, no-store, must-revalidate\r\nPragma: no-cache\r\nConnection: close\r\n\r\n"
        if let headerData = responseHeader.data(using: .utf8) {
            connection.send(content: headerData, completion: .contentProcessed({ [weak self] error in
                if error == nil {
                    self?.activeConnections.append(connection)
                }
            }))
        }
    }

    private func broadcastLatestFrame() {
        guard !activeConnections.isEmpty,
              let jpegData = ScreenFrameHub.shared.latestJPEGFrame else { return }

        let frameHeader = "--carplayframe\r\nContent-Type: image/jpeg\r\nContent-Length: \(jpegData.count)\r\n\r\n"
        guard let headerData = frameHeader.data(using: .utf8),
              let tailData = "\r\n".data(using: .utf8) else { return }

        var packet = Data()
        packet.append(headerData)
        packet.append(jpegData)
        packet.append(tailData)

        queue.async { [weak self] in
            guard let self = self else { return }
            self.activeConnections.removeAll { conn in
                if conn.state != .ready { return true }
                conn.send(content: packet, completion: .contentProcessed({ error in
                    if error != nil { conn.cancel() }
                }))
                return false
            }
        }
    }

    static func localIPAddress() -> String? {
        var address: String?
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr {
            for ptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
                let flags = Int32(ptr.pointee.ifa_flags)
                let addr = ptr.pointee.ifa_addr.pointee
                if (flags & (IFF_UP | IFF_RUNNING | IFF_LOOPBACK)) == (IFF_UP | IFF_RUNNING),
                   addr.sa_family == UInt8(AF_INET) {
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    if getnameinfo(ptr.pointee.ifa_addr, socklen_t(addr.sa_len),
                                   &hostname, socklen_t(hostname.count),
                                   nil, socklen_t(0), NI_NUMERICHOST) == 0 {
                        let ip = String(cString: hostname)
                        if ip.hasPrefix("192.168.") || ip.hasPrefix("172.") || ip.hasPrefix("10.") {
                            address = ip
                            break
                        }
                    }
                }
            }
            freeifaddrs(ifaddr)
        }
        return address
    }
}

// MARK: - 3. CarPlay 车机屏幕渲染控制器 (支持视频自动旋转与 16:9 智能满屏适配)
final class CarPlayMirrorViewController: UIViewController {
    private let mirrorImageView = UIImageView()
    private let statusLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupUI()
        bindFrameStream()
    }

    private func setupUI() {
        mirrorImageView.translatesAutoresizingMaskIntoConstraints = false
        mirrorImageView.contentMode = .scaleAspectFit
        mirrorImageView.clipsToBounds = true
        mirrorImageView.backgroundColor = .black
        view.addSubview(mirrorImageView)

        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.text = "已连接 2019款 科鲁泽 8英寸车机\n请在 iPhone 16e 上点击录制图标开启全局投屏"
        statusLabel.textColor = .lightGray
        statusLabel.numberOfLines = 0
        statusLabel.textAlignment = .center
        statusLabel.font = .systemFont(ofSize: 16, weight: .medium)
        view.addSubview(statusLabel)

        NSLayoutConstraint.activate([
            mirrorImageView.topAnchor.constraint(equalTo: view.topAnchor),
            mirrorImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            mirrorImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mirrorImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            statusLabel.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])
    }

    private func bindFrameStream() {
        ScreenFrameHub.shared.onFrameImageUpdate = { [weak self] image, isLandscapeFrame in
            guard let self = self else { return }
            self.statusLabel.isHidden = true
            self.mirrorImageView.image = image

            // 根据旋转模式自动适配科鲁泽 8 英寸横屏比例
            switch ScreenFrameHub.shared.rotationMode {
            case .autoSmart:
                // 智能模式：当播放横屏视频（宽>=高）时自动自适应填满宽屏，竖屏操作时保持等比完整显示
                let imageRatio = image.size.width / max(image.size.height, 1)
                let screenRatio = self.view.bounds.width / max(self.view.bounds.height, 1)
                if isLandscapeFrame && abs(imageRatio - screenRatio) < 0.45 {
                    self.mirrorImageView.contentMode = .scaleAspectFill
                } else {
                    self.mirrorImageView.contentMode = .scaleAspectFit
                }
            case .forceLandscape:
                self.mirrorImageView.contentMode = .scaleAspectFit
            case .forceFill:
                self.mirrorImageView.contentMode = .scaleAspectFill
            }
        }
    }

    func cycleRotationMode() {
        let nextRaw = (ScreenFrameHub.shared.rotationMode.rawValue + 1) % 3
        ScreenFrameHub.shared.rotationMode = VideoRotationMode(rawValue: nextRaw) ?? .autoSmart
    }
}

// MARK: - 4. CarPlay 场景代理 (自动兼容有线 USB 与无线 CarPlay 连接)
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {
    var interfaceController: CPInterfaceController?
    var carWindow: CPWindow?
    private var mirrorVC: CarPlayMirrorViewController?

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController,
                                  to window: CPWindow) {
        self.interfaceController = interfaceController
        self.carWindow = window
        ScreenFrameHub.shared.isCarPlayConnected = true

        let vc = CarPlayMirrorViewController()
        self.mirrorVC = vc
        window.rootViewController = vc
        window.makeKeyAndVisible()

        let mapTemplate = CPMapTemplate()
        let rotateBarButton = CPBarButton(title: "切换旋转/全屏") { [weak self] _ in
            self?.mirrorVC?.cycleRotationMode()
        }
        mapTemplate.leadingNavigationBarButtons = [rotateBarButton]
        interfaceController.setRootTemplate(mapTemplate, animated: true, completion: nil)
    }

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController) {
        self.interfaceController = interfaceController
        ScreenFrameHub.shared.isCarPlayConnected = true
        let ip = LocalMJPEGServer.localIPAddress() ?? "127.0.0.1"
        let item = CPListItem(
            text: "全局屏幕镜像已就绪（支持自动横屏）",
            detailText: "流地址: http://\(ip):8080/stream"
        )
        let section = CPListSection(items: [item], header: "2019款 科鲁泽 1.3T 投屏助手 v2.0", sectionIndexTitle: nil)
        let listTemplate = CPListTemplate(title: "科鲁泽投屏", sections: [section])
        interfaceController.setRootTemplate(listTemplate, animated: true, completion: nil)
    }

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didDisconnect interfaceController: CPInterfaceController,
                                  from window: CPWindow) {
        ScreenFrameHub.shared.isCarPlayConnected = false
        self.interfaceController = nil
        self.carWindow = nil
        self.mirrorVC = nil
    }
}

// MARK: - 5. iPhone 16e 手机端主控界面 (修复重叠 + 新增自动旋转与有线/无线模式控制)
final class PhoneMirrorControlViewController: UIViewController {
    private let scrollView = UIScrollView()
    private let contentStack = UIStackView()
    private let statusCard = UIView()
    private let statusLabel = UILabel()
    private let connectionModeLabel = UILabel()

    private let rotationSegment = UISegmentedControl(items: ["智能自动横屏", "强制横屏90°", "强制铺满车机"])
    private let qualitySegment = UISegmentedControl(items: ["有线高清(USB)", "无线流畅(Wi-Fi)"])

    private let startCaptureButton = UIButton(type: .system)
    private let broadcastContainer = UIView()
    private let broadcastPicker = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 64, height: 64))
    private let broadcastHintLabel = UILabel()
    private let infoLabel = UILabel()
    private var isCapturing = false

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "科鲁泽 CarPlay 投屏助手 v2.0"
        view.backgroundColor = .systemGroupedBackground
        setupUI()
        LocalMJPEGServer.shared.start()

        ScreenFrameHub.shared.onCarPlayConnectionChanged = { [weak self] connected in
            self?.updateConnectionBanner(connected: connected)
        }
    }

    private func setupUI() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        contentStack.axis = .vertical
        contentStack.spacing = 18
        contentStack.alignment = .fill
        contentStack.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentStack)

        // 1. 顶部状态卡片（彻底避免与导航栏标题重叠）
        statusCard.backgroundColor = .secondarySystemGroupedBackground
        statusCard.layer.cornerRadius = 14
        statusCard.translatesAutoresizingMaskIntoConstraints = false

        statusLabel.text = "状态：待机中（支持视频自动横屏与比例自适应）"
        statusLabel.font = .systemFont(ofSize: 15, weight: .semibold)
        statusLabel.textColor = .systemGreen
        statusLabel.numberOfLines = 0
        statusLabel.textAlignment = .center

        connectionModeLabel.text = "车载连接：正在监听有线 USB / 无线 CarPlay 自动接入..."
        connectionModeLabel.font = .systemFont(ofSize: 13)
        connectionModeLabel.textColor = .secondaryLabel
        connectionModeLabel.numberOfLines = 0
        connectionModeLabel.textAlignment = .center

        let cardStack = UIStackView(arrangedSubviews: [statusLabel, connectionModeLabel])
        cardStack.axis = .vertical
        cardStack.spacing = 6
        cardStack.translatesAutoresizingMaskIntoConstraints = false
        statusCard.addSubview(cardStack)

        NSLayoutConstraint.activate([
            cardStack.topAnchor.constraint(equalTo: statusCard.topAnchor, constant: 14),
            cardStack.bottomAnchor.constraint(equalTo: statusCard.bottomAnchor, constant: -14),
            cardStack.leadingAnchor.constraint(equalTo: statusCard.leadingAnchor, constant: 14),
            cardStack.trailingAnchor.constraint(equalTo: statusCard.trailingAnchor, constant: -14)
        ])

        // 2. 视频旋转与车机自适应选项
        let rotTitle = makeSectionHeader("一、视频播放旋转与车机屏幕自适应")
        rotationSegment.selectedSegmentIndex = ScreenFrameHub.shared.rotationMode.rawValue
        rotationSegment.addTarget(self, action: #selector(onRotationModeChanged), for: .valueChanged)

        // 3. 有线 / 无线 CarPlay 传输优化选项
        let qualTitle = makeSectionHeader("二、连接方式画质优化（有线/无线自动兼容）")
        qualitySegment.selectedSegmentIndex = ScreenFrameHub.shared.qualityMode.rawValue
        qualitySegment.addTarget(self, action: #selector(onQualityModeChanged), for: .valueChanged)

        // 4. 启动按钮
        startCaptureButton.setTitle("方式 A：启动应用内屏幕采集", for: .normal)
        startCaptureButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .bold)
        startCaptureButton.backgroundColor = .systemBlue
        startCaptureButton.setTitleColor(.white, for: .normal)
        startCaptureButton.layer.cornerRadius = 12
        startCaptureButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        startCaptureButton.addTarget(self, action: #selector(toggleScreenCapture), for: .touchUpInside)

        // 5. 跨应用全局录制按钮
        broadcastContainer.backgroundColor = .secondarySystemGroupedBackground
        broadcastContainer.layer.cornerRadius = 14
        broadcastContainer.translatesAutoresizingMaskIntoConstraints = false

        broadcastPicker.preferredExtension = "com.monza.carplay.mirror.BroadcastUploadExtension"
        broadcastPicker.showsMicrophoneButton = false
        broadcastPicker.translatesAutoresizingMaskIntoConstraints = false

        broadcastHintLabel.text = "方式 B：点击上方黑色圆点开启「跨应用全局投屏」\n（开启后退回桌面打开抖音/B站/高德，全屏看视频将自动横屏铺满车机）"
        broadcastHintLabel.font = .systemFont(ofSize: 13)
        broadcastHintLabel.textColor = .secondaryLabel
        broadcastHintLabel.numberOfLines = 0
        broadcastHintLabel.textAlignment = .center
        broadcastHintLabel.translatesAutoresizingMaskIntoConstraints = false

        broadcastContainer.addSubview(broadcastPicker)
        broadcastContainer.addSubview(broadcastHintLabel)

        NSLayoutConstraint.activate([
            broadcastPicker.topAnchor.constraint(equalTo: broadcastContainer.topAnchor, constant: 12),
            broadcastPicker.centerXAnchor.constraint(equalTo: broadcastContainer.centerXAnchor),
            broadcastPicker.widthAnchor.constraint(equalToConstant: 60),
            broadcastPicker.heightAnchor.constraint(equalToConstant: 60),

            broadcastHintLabel.topAnchor.constraint(equalTo: broadcastPicker.bottomAnchor, constant: 8),
            broadcastHintLabel.leadingAnchor.constraint(equalTo: broadcastContainer.leadingAnchor, constant: 12),
            broadcastHintLabel.trailingAnchor.constraint(equalTo: broadcastContainer.trailingAnchor, constant: -12),
            broadcastHintLabel.bottomAnchor.constraint(equalTo: broadcastContainer.bottomAnchor, constant: -14)
        ])

        // 6. 底部说明
        let ip = LocalMJPEGServer.localIPAddress() ?? "请连接 Wi-Fi 或开启热点"
        infoLabel.text = "使用提示（iPhone 16e · 19款科鲁泽 1.3T）：\n• 自动横屏说明：选择「智能自动横屏」时，手机横屏全屏播放视频会自动摆正并铺满科鲁泽 8 英寸屏幕；若您习惯锁死手机竖屏看横屏视频，可点「强制横屏90°」。\n• 有线/无线说明：系统底层自动兼容有线 USB 与无线 CarPlay，无需手动切换连接协议；插线用建议选「有线高清」，用无线转接盒建议选「无线流畅」。\n• 局域网镜像流地址：http://\(ip):8080/stream"
        infoLabel.font = .systemFont(ofSize: 13)
        infoLabel.textColor = .secondaryLabel
        infoLabel.numberOfLines = 0

        [statusCard, rotTitle, rotationSegment, qualTitle, qualitySegment, startCaptureButton, broadcastContainer, infoLabel].forEach {
            contentStack.addArrangedSubview($0)
        }

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: guide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),

            contentStack.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 16),
            contentStack.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -24),
            contentStack.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 20),
            contentStack.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -20),
            contentStack.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -40)
        ])
    }

    private func makeSectionHeader(_ text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.textColor = .label
        return label
    }

    private func updateConnectionBanner(connected: Bool) {
        if connected {
            connectionModeLabel.text = "车载连接：已成功接入科鲁泽 CarPlay 车机屏幕（有线/无线通道已激活）"
            connectionModeLabel.textColor = .systemBlue
        } else {
            connectionModeLabel.text = "车载连接：未检测到车机连接（请插入科鲁泽 USB 接口或连接无线 CarPlay）"
            connectionModeLabel.textColor = .secondaryLabel
        }
    }

    @objc private func onRotationModeChanged() {
        if let mode = VideoRotationMode(rawValue: rotationSegment.selectedSegmentIndex) {
            ScreenFrameHub.shared.rotationMode = mode
        }
    }

    @objc private func onQualityModeChanged() {
        if let qMode = ConnectionQualityMode(rawValue: qualitySegment.selectedSegmentIndex) {
            ScreenFrameHub.shared.qualityMode = qMode
        }
    }

    @objc private func toggleScreenCapture() {
        let recorder = RPScreenRecorder.shared()
        if !isCapturing {
            guard recorder.isAvailable else {
                statusLabel.text = "错误：当前系统屏幕录制不可用"
                statusLabel.textColor = .systemRed
                return
            }
            recorder.isMicrophoneEnabled = false
            recorder.startCapture(handler: { sampleBuffer, sampleType, error in
                if sampleType == .video, error == nil {
                    ScreenFrameHub.shared.processVideoSampleBuffer(sampleBuffer)
                }
            }, completionHandler: { [weak self] error in
                DispatchQueue.main.async {
                    if let error = error {
                        self?.statusLabel.text = "采集启动失败：\(error.localizedDescription)"
                        self?.statusLabel.textColor = .systemRed
                    } else {
                        self?.isCapturing = true
                        self?.statusLabel.text = "状态：正在实时投屏（已启用视频自动横屏自适应）"
                        self?.statusLabel.textColor = .systemGreen
                        self?.startCaptureButton.setTitle("停止屏幕投屏采集", for: .normal)
                        self?.startCaptureButton.backgroundColor = .systemRed
                    }
                }
            })
        } else {
            recorder.stopCapture { [weak self] _ in
                DispatchQueue.main.async {
                    self?.isCapturing = false
                    self?.statusLabel.text = "状态：已停止投屏"
                    self?.startCaptureButton.setTitle("方式 A：启动应用内屏幕采集", for: .normal)
                    self?.startCaptureButton.backgroundColor = .systemBlue
                }
            }
        }
    }
}

// MARK: - 6. iOS 应用入口与手机场景代理 (App & Phone Scene Entry)
@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }

    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        if connectingSceneSession.role == UISceneSession.Role.carTemplateApplication {
            let config = UISceneConfiguration(name: "CarPlayConfiguration", sessionRole: connectingSceneSession.role)
            config.delegateClass = CarPlaySceneDelegate.self
            return config
        } else {
            let config = UISceneConfiguration(name: "PhoneDefaultConfiguration", sessionRole: connectingSceneSession.role)
            config.delegateClass = SceneDelegate.self
            return config
        }
    }
}

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        let window = UIWindow(windowScene: windowScene)
        let nav = UINavigationController(rootViewController: PhoneMirrorControlViewController())
        window.rootViewController = nav
        self.window = window
        window.makeKeyAndVisible()
    }
}
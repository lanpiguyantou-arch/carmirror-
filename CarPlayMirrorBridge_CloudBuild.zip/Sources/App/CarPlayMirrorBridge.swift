//
//  CarPlayMirrorBridge.swift
//  CarPlayMirrorBridge
//
//  适用场景：
//  1. 车型适配：2019款 雪佛兰科鲁泽 330T (1.3T) — 8英寸 MyLink+ 车载屏幕（支持有线 Apple CarPlay）
//  2. 手机环境：iPhone 16e (iOS 26.6.1)
//
//  核心架构说明：
//  由于未越狱的 iOS 26.6.1 系统沙盒禁止第三方应用直接抓取其他 App 的 UIWindow 句柄，
//  本工程采用【ReplayKit 全局屏幕广播扩展 + App Group 共享内存环形缓冲区 + CarPlay CPWindow 渲染 + 本地 MJPEG 流服务】方案：
//    - 模块 1（BroadcastUploadExtension 跨应用录屏扩展）：基于 RPBroadcastSampleHandler，当用户退回桌面打开抖音、B站、
//      高德地图或任意第三方 App 时，由系统级扩展在后台持续捕获 60fps 屏幕画面并写入 App Group 共享高速缓存。
//    - 模块 2（CarPlay 原生 CPWindow 画布渲染）：通过 CPTemplateApplicationSceneDelegate 接管科鲁泽 8 英寸车机窗口，
//      实时读取共享帧并渲染到车机屏幕，支持在车机触屏上切换 16:9 铺满 / 等比缩放。
//    - 模块 3（本地零依赖 HTTP MJPEG 投屏服务）：内置 Network.framework 推流服务（端口 8080），兼容无线投屏盒及车载浏览器。
//

import UIKit
import CarPlay
import ReplayKit
import Network
import AVFoundation

// MARK: - 0. 跨进程共享配置常量 (App Group Configuration)
enum MirrorSharedConfig {
    /// 请在 Xcode -> Signing & Capabilities 中为的主 App 与 Broadcast Extension 同时勾选此 App Group
    static let appGroupIdentifier = "group.com.monza.carplay.mirror"
    static let latestFrameFileName = "latest_screen_frame.jpg"
    static let frameUpdatedNotification = "com.monza.carplay.mirror.frameUpdated" as CFString
    static let defaultHTTPPort: UInt16 = 8080

    static var sharedFrameFileURL: URL? {
        FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier)?
            .appendingPathComponent(latestFrameFileName)
    }
}

// MARK: - 1. 屏幕帧分发与跨进程同步中心 (ScreenFrameHub)
/// 负责将 ReplayKit（应用内或系统级 Broadcast Extension）捕获的 CMSampleBuffer 转换为 JPEG 帧，
/// 并同步分发给 CarPlay 车机窗口与本地局域网 MJPEG 流媒体服务器
final class ScreenFrameHub {
    static let shared = ScreenFrameHub()

    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    private let lock = NSLock()

    /// 供 CarPlay CPWindow 实时渲染的回调
    var onFrameImageUpdate: ((UIImage) -> Void)?

    /// 最新的 JPEG 压缩帧数据（供 MJPEG 流服务与跨进程同步读取）
    private(set) var latestJPEGFrame: Data?

    private init() {
        registerForCrossProcessFrameNotifications()
    }

    /// 监听来自 BroadcastUploadExtension 的跨进程 Darwin 通知，实现后台任意 App 画面同步
    private func registerForCrossProcessFrameNotifications() {
        let center = CFNotificationCenterGetDarwinNotifyCenter()
        let observer = Unmanaged.passUnretained(self).toOpaque()
        CFNotificationCenterAddObserver(
            center,
            observer,
            { _, observer, _, _, _ in
                guard let observer = observer else { return }
                let hub = Unmanaged<ScreenFrameHub>.fromOpaque(observer).takeUnretainedValue()
                hub.loadFrameFromAppGroup()
            },
            MirrorSharedConfig.frameUpdatedNotification,
            nil,
            .deliverImmediately
        )
    }

    /// 从 App Group 共享容器中读取后台录屏扩展写入的最新屏幕帧
    private func loadFrameFromAppGroup() {
        guard let fileURL = MirrorSharedConfig.sharedFrameFileURL,
              let data = try? Data(contentsOf: fileURL),
              let image = UIImage(data: data) else { return }

        lock.lock()
        self.latestJPEGFrame = data
        lock.unlock()

        DispatchQueue.main.async { [weak self] in
            self?.onFrameImageUpdate?(image)
        }
    }

    /// 处理 ReplayKit 捕获到的视频样本帧
    /// - Parameter sampleBuffer: 系统屏幕视频帧
    /// - Parameter writeToAppGroup: 若在 Broadcast Extension 中运行则设为 true，通过共享容器传递给主进程 CarPlay
    func processVideoSampleBuffer(_ sampleBuffer: CMSampleBuffer, writeToAppGroup: Bool = false) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        let rect = CGRect(x: 0, y: 0, width: width, height: height)

        guard let cgImage = ciContext.createCGImage(ciImage, from: rect) else { return }
        let uiImage = UIImage(cgImage: cgImage)

        // 压缩为适配 2019款科鲁泽 8英寸屏幕带宽的 JPEG 数据 (0.65 质量兼顾清晰度与低延迟)
        guard let jpegData = uiImage.jpegData(compressionQuality: 0.65) else { return }

        lock.lock()
        self.latestJPEGFrame = jpegData
        lock.unlock()

        if writeToAppGroup, let sharedURL = MirrorSharedConfig.sharedFrameFileURL {
            try? jpegData.write(to: sharedURL, options: .atomic)
            CFNotificationCenterPostNotification(
                CFNotificationCenterGetDarwinNotifyCenter(),
                CFNotificationName(MirrorSharedConfig.frameUpdatedNotification),
                nil,
                nil,
                true
            )
        } else {
            DispatchQueue.main.async { [weak self] in
                self?.onFrameImageUpdate?(uiImage)
            }
        }
    }
}

// MARK: - 2. 系统级全局屏幕广播扩展处理器 (Broadcast Upload Extension Target)
/// 将此类添加到 Xcode 的「Broadcast Upload Extension」Target 中，即可在退回 iOS 桌面后投屏任意第三方 App
final class CarPlayBroadcastSampleHandler: RPBroadcastSampleHandler {
    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        // 全局屏幕直播已启动（此时可切换到抖音、B站、高德、微信等任意应用）
    }

    override func broadcastPaused() {}
    override func broadcastResumed() {}
    override func broadcastFinished() {}

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) {
        switch sampleBufferType {
        case .video:
            // 将全局屏幕帧写入 App Group 并通过 Darwin 通知唤醒主应用刷新 CarPlay 画面
            ScreenFrameHub.shared.processVideoSampleBuffer(sampleBuffer, writeToAppGroup: true)
        case .audioApp, .audioMic:
            // 音频自动通过系统有线 CarPlay 音频通道直通 2019款科鲁泽 原车音响，无需二次编码
            break
        @unknown default:
            break
        }
    }
}

// MARK: - 3. 本地低延迟 MJPEG 投屏服务器 (Local Mirror Server)
/// 使用 Apple Network.framework 实现零依赖 HTTP MJPEG 流媒体服务
final class LocalMJPEGServer {
    static let shared = LocalMJPEGServer()
    private var listener: NWListener?
    private var activeConnections: [NWConnection] = []
    private var streamTimer: Timer?
    private let queue = DispatchQueue(label: "com.monza.carplay.mjpegserver", qos: .userInteractive)

    private(set) var isRunning = false
    let port: UInt16 = MirrorSharedConfig.defaultHTTPPort

    func start() {
        guard !isRunning else { return }
        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            listener = try NWListener(using: params, on: NWEndpoint.Port(rawValue: port)!)
        } catch {
            print("[MJPEGServer] 启动监听失败: \(error.localizedDescription)")
            return
        }

        listener?.newConnectionHandler = { [weak self] connection in
            self?.handleNewConnection(connection)
        }

        listener?.stateUpdateHandler = { [weak self] state in
            switch state {
            case .ready:
                self?.isRunning = true
                print("[MJPEGServer] 已启动，局域网投屏地址: http://\(Self.localIPAddress() ?? "127.0.0.1"):\(self?.port ?? 8080)/stream")
            case .failed(let error):
                self?.isRunning = false
                print("[MJPEGServer] 监听异常: \(error.localizedDescription)")
            default:
                break
            }
        }

        listener?.start(queue: queue)

        // 启动 30fps 定时推流循环
        DispatchQueue.main.async {
            self.streamTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
                self?.broadcastLatestFrame()
            }
        }
    }

    func stop() {
        streamTimer?.invalidate()
        streamTimer = nil
        activeConnections.forEach { $0.cancel() }
        activeConnections.removeAll()
        listener?.cancel()
        listener = nil
        isRunning = false
    }

    private func handleNewConnection(_ connection: NWConnection) {
        connection.start(queue: queue)
        let responseHeader = """
        HTTP/1.1 200 OK\r
        Content-Type: multipart/x-mixed-replace; boundary=carplayframe\r
        Cache-Control: no-cache, no-store, must-revalidate\r
        Pragma: no-cache\r
        Connection: close\r
        \r\n
        """
        if let headerData = responseHeader.data(using: .utf8) {
            connection.send(content: headerData, completion: .contentProcessed({ [weak self] error in
                if error == nil {
                    self?.activeConnections.append(connection)
                }
            }))
        }
    }

    private func broadcastLatestFrame() {
        guard !activeConnections.isEmpty,
              let jpegData = ScreenFrameHub.shared.latestJPEGFrame else { return }

        let frameHeader = "--carplayframe\r\nContent-Type: image/jpeg\r\nContent-Length: \(jpegData.count)\r\n\r\n"
        guard let headerData = frameHeader.data(using: .utf8),
              let tailData = "\r\n".data(using: .utf8) else { return }

        var packet = Data()
        packet.append(headerData)
        packet.append(jpegData)
        packet.append(tailData)

        queue.async { [weak self] in
            guard let self = self else { return }
            self.activeConnections.removeAll { conn in
                if conn.state != .ready { return true }
                conn.send(content: packet, completion: .contentProcessed({ error in
                    if error != nil {
                        conn.cancel()
                    }
                }))
                return false
            }
        }
    }

    /// 获取本机局域网 IP 地址
    static func localIPAddress() -> String? {
        var address: String?
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr {
            for ptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
                let flags = Int32(ptr.pointee.ifa_flags)
                let addr = ptr.pointee.ifa_addr.pointee
                if (flags & (IFF_UP | IFF_RUNNING | IFF_LOOPBACK)) == (IFF_UP | IFF_RUNNING),
                   addr.sa_family == UInt8(AF_INET) {
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    if getnameinfo(ptr.pointee.ifa_addr, socklen_t(addr.sa_len),
                                   &hostname, socklen_t(hostname.count),
                                   nil, socklen_t(0), NI_NUMERICHOST) == 0 {
                        let ip = String(cString: hostname)
                        if ip.hasPrefix("192.168.") || ip.hasPrefix("172.") || ip.hasPrefix("10.") {
                            address = ip
                            break
                        }
                    }
                }
            }
            freeifaddrs(ifaddr)
        }
        return address
    }
}

// MARK: - 4. CarPlay 车机屏幕渲染控制器 (2019款 科鲁泽 8英寸 MyLink+ 适配)
/// 挂载在 CarPlay CPWindow 上的全屏镜像视图控制器
final class CarPlayMirrorViewController: UIViewController {
    private let mirrorImageView = UIImageView()
    private let statusLabel = UILabel()
    private var aspectMode: UIView.ContentMode = .scaleAspectFit

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupUI()
        bindFrameStream()
    }

    private func setupUI() {
        // 画面显示层（针对 19款科鲁泽 8英寸横屏优化）
        mirrorImageView.translatesAutoresizingMaskIntoConstraints = false
        mirrorImageView.contentMode = aspectMode
        mirrorImageView.backgroundColor = .black
        view.addSubview(mirrorImageView)

        // 待机状态提示层
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.text = "请在 iPhone 16e 上点击「开启全局屏幕镜像」\n之后打开任何 App 均可实时投屏至科鲁泽车机"
        statusLabel.textColor = .lightGray
        statusLabel.numberOfLines = 0
        statusLabel.textAlignment = .center
        statusLabel.font = .systemFont(ofSize: 16, weight: .medium)
        view.addSubview(statusLabel)

        NSLayoutConstraint.activate([
            mirrorImageView.topAnchor.constraint(equalTo: view.topAnchor),
            mirrorImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            mirrorImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mirrorImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            statusLabel.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])
    }

    private func bindFrameStream() {
        ScreenFrameHub.shared.onFrameImageUpdate = { [weak self] image in
            guard let self = self else { return }
            self.statusLabel.isHidden = true
            self.mirrorImageView.image = image
        }
    }

    /// 切换等比缩放 / 铺满全屏（适配科鲁泽 8 英寸 16:9 屏幕）
    func toggleScaleMode() {
        aspectMode = (aspectMode == .scaleAspectFit) ? .scaleAspectFill : .scaleAspectFit
        mirrorImageView.contentMode = aspectMode
    }
}

// MARK: - 5. CarPlay 场景代理 (CPTemplateApplicationSceneDelegate)
/// 负责当 iPhone 通过 USB 插入 2019款科鲁泽 1.3T 时，初始化 CarPlay 界面与 CPWindow 画布
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {
    var interfaceController: CPInterfaceController?
    var carWindow: CPWindow?
    private var mirrorVC: CarPlayMirrorViewController?

    /// 当连接包含 CPWindow 的 CarPlay 场景时调用（需配置 com.apple.developer.carplay-maps 权限以启用自定义画布）
    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController,
                                  to window: CPWindow) {
        self.interfaceController = interfaceController
        self.carWindow = window

        // 1. 绑定自定义全屏投屏视图控制器到科鲁泽车机窗口
        let vc = CarPlayMirrorViewController()
        self.mirrorVC = vc
        window.rootViewController = vc
        window.makeKeyAndVisible()

        // 2. 配置 CarPlay 顶部导航控制栏按钮（支持在车机触屏上切换画面比例）
        let mapTemplate = CPMapTemplate()
        let aspectBarButton = CPBarButton(title: "切换画面比例") { [weak self] _ in
            self?.mirrorVC?.toggleScaleMode()
        }
        mapTemplate.leadingNavigationBarButtons = [aspectBarButton]
        interfaceController.setRootTemplate(mapTemplate, animated: true, completion: nil)
    }

    /// 兼容不带 CPWindow 的标准 CarPlay 模板连接模式
    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController) {
        self.interfaceController = interfaceController
        let ip = LocalMJPEGServer.localIPAddress() ?? "127.0.0.1"
        let item = CPListItem(
            text: "全局屏幕镜像服务已就绪",
            detailText: "流媒体地址: http://\(ip):8080/stream"
        )
        let section = CPListSection(items: [item], header: "2019款 科鲁泽 1.3T 投屏助手", sectionIndexTitle: nil)
        let listTemplate = CPListTemplate(title: "任意软件投屏", sections: [section])
        interfaceController.setRootTemplate(listTemplate, animated: true, completion: nil)
    }

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didDisconnect interfaceController: CPInterfaceController,
                                  from window: CPWindow) {
        self.interfaceController = nil
        self.carWindow = nil
        self.mirrorVC = nil
    }
}

// MARK: - 6. iPhone 手机端主控界面 (Phone Control ViewController)
/// 在 iPhone 16e 上运行的主界面：管理 ReplayKit 录屏采集与本地流服务
final class PhoneMirrorControlViewController: UIViewController {
    private let statusBadge = UILabel()
    private let startCaptureButton = UIButton(type: .system)
    private let broadcastPicker = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 64, height: 64))
    private let infoLabel = UILabel()
    private var isCapturing = false

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "科鲁泽 CarPlay 投屏助手"
        view.backgroundColor = .systemBackground
        setupPhoneUI()
        LocalMJPEGServer.shared.start()
    }

    private func setupPhoneUI() {
        let ip = LocalMJPEGServer.localIPAddress() ?? "请连接 Wi-Fi 或个人热点"

        statusBadge.text = "状态：待机中（已适配 2019款 科鲁泽 1.3T 8英寸车机）"
        statusBadge.font = .systemFont(ofSize: 15, weight: .semibold)
        statusBadge.textColor = .systemGreen
        statusBadge.numberOfLines = 0
        statusBadge.textAlignment = .center

        startCaptureButton.setTitle("方式 A：启动应用内屏幕采集", for: .normal)
        startCaptureButton.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold)
        startCaptureButton.backgroundColor = .systemBlue
        startCaptureButton.setTitleColor(.white, for: .normal)
        startCaptureButton.layer.cornerRadius = 12
        startCaptureButton.addTarget(self, action: #selector(toggleScreenCapture), for: .touchUpInside)

        // 方式 B：系统级跨应用 Broadcast Picker（支持退到后台打开抖音/高德/B站等任意软件）
        broadcastPicker.preferredExtension = "com.monza.carplay.mirror.BroadcastUploadExtension"
        broadcastPicker.showsMicrophoneButton = false

        infoLabel.text = """
        使用说明（iPhone 16e · iOS 26.6.1）：
        1. 用 USB-C 转 USB-A 数据线将 iPhone 16e 连接至 19款科鲁泽中控 USB 接口唤醒 CarPlay。
        2. 点击上方圆形「屏幕广播图标」开启跨应用全局镜像，随后退回桌面打开任何软件，画面将实时同步到车机。
        3. 局域网镜像流地址：http://\(ip):8080/stream
        """
        infoLabel.font = .systemFont(ofSize: 14)
        infoLabel.textColor = .secondaryLabel
        infoLabel.numberOfLines = 0

        let stack = UIStackView(arrangedSubviews: [statusBadge, startCaptureButton, broadcastPicker, infoLabel])
        stack.axis = .vertical
        stack.spacing = 24
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            startCaptureButton.widthAnchor.constraint(equalTo: stack.widthAnchor),
            startCaptureButton.heightAnchor.constraint(equalToConstant: 52),
            broadcastPicker.widthAnchor.constraint(equalToConstant: 64),
            broadcastPicker.heightAnchor.constraint(equalToConstant: 64)
        ])
    }

    @objc private func toggleScreenCapture() {
        let recorder = RPScreenRecorder.shared()
        if !isCapturing {
            guard recorder.isAvailable else {
                statusBadge.text = "错误：当前系统屏幕录制不可用"
                statusBadge.textColor = .systemRed
                return
            }
            recorder.isMicrophoneEnabled = false
            recorder.startCapture(handler: { sampleBuffer, sampleType, error in
                if sampleType == .video, error == nil {
                    ScreenFrameHub.shared.processVideoSampleBuffer(sampleBuffer)
                }
            }, completionHandler: { [weak self] error in
                DispatchQueue.main.async {
                    if let error = error {
                        self?.statusBadge.text = "采集启动失败：\(error.localizedDescription)"
                        self?.statusBadge.textColor = .systemRed
                    } else {
                        self?.isCapturing = true
                        self?.statusBadge.text = "状态：正在实时投屏至科鲁泽 8 英寸车机"
                        self?.startCaptureButton.setTitle("停止屏幕投屏采集", for: .normal)
                        self?.startCaptureButton.backgroundColor = .systemRed
                    }
                }
            })
        } else {
            recorder.stopCapture { [weak self] _ in
                DispatchQueue.main.async {
                    self?.isCapturing = false
                    self?.statusBadge.text = "状态：已停止投屏"
                    self?.startCaptureButton.setTitle("方式 A：启动应用内屏幕采集", for: .normal)
                    self?.startCaptureButton.backgroundColor = .systemBlue
                }
            }
        }
    }
}

// MARK: - 7. iOS 应用入口与手机场景代理 (App & Phone Scene Entry)
@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }

    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        if connectingSceneSession.role == UISceneSession.Role.carTemplateApplication {
            let config = UISceneConfiguration(name: "CarPlayConfiguration", sessionRole: connectingSceneSession.role)
            config.delegateClass = CarPlaySceneDelegate.self
            return config
        } else {
            let config = UISceneConfiguration(name: "PhoneDefaultConfiguration", sessionRole: connectingSceneSession.role)
            config.delegateClass = SceneDelegate.self
            return config
        }
    }
}

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        let window = UIWindow(windowScene: windowScene)
        let nav = UINavigationController(rootViewController: PhoneMirrorControlViewController())
        window.rootViewController = nav
        self.window = window
        window.makeKeyAndVisible()
    }
}

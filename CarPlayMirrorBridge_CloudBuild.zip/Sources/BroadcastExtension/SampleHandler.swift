//
//  SampleHandler.swift
//  BroadcastUploadExtension
//

import ReplayKit
import UIKit
import ImageIO
import CoreImage

final class SampleHandler: RPBroadcastSampleHandler {
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    private let appGroupID = "group.com.monza.carplay.mirror"
    private let frameFileName = "latest_screen_frame.jpg"
    private let notifyName = "com.monza.carplay.mirror.frameUpdated" as CFString

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {}
    override func broadcastPaused() {}
    override func broadcastResumed() {}
    override func broadcastFinished() {}

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) {
        guard sampleBufferType == .video,
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        var ciImage = CIImage(cvPixelBuffer: pixelBuffer)

        if let orientationAttachment = CMGetAttachment(sampleBuffer, key: RPVideoSampleOrientationKey as CFString, attachmentModeOut: nil) as? NSNumber,
           let orientation = CGImagePropertyOrientation(rawValue: orientationAttachment.uint32Value) {
            ciImage = ciImage.oriented(orientation)
        }

        let defaults = UserDefaults(suiteName: appGroupID)
        let rotMode = defaults?.integer(forKey: "mirror_rotation_mode") ?? 0
        if rotMode == 1 && ciImage.extent.height > ciImage.extent.width {
            ciImage = ciImage.oriented(.left)
        }

        let qualMode = defaults?.integer(forKey: "mirror_link_quality_mode") ?? 0
        let jpegQuality: CGFloat = (qualMode == 1) ? 0.50 : 0.75

        guard let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else { return }
        let uiImage = UIImage(cgImage: cgImage)
        guard let jpegData = uiImage.jpegData(compressionQuality: jpegQuality),
              let containerURL = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID) else { return }

        let fileURL = containerURL.appendingPathComponent(frameFileName)
        try? jpegData.write(to: fileURL, options: .atomic)

        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(notifyName),
            nil,
            nil,
            true
        )
    }
}

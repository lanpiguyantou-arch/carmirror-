# 2019款 雪佛兰科鲁泽 1.3T · iPhone 16e (iOS 26.6.1) CarPlay 任意软件投屏指南与工程说明

本工程针对您的 **[iPhone 16e](https://www.google.com/search?q=https%3A%2F%2Fwww.apple.com%2Fnewsroom%2F2025%2F02%2Fapple-debuts-iphone-16e-a-powerful-new-member-of-the-iphone-16-family%2F)（运行 [iOS 26.6.1](https://www.google.com/search?q=https%3A%2F%2Fsupport.apple.com%2Fen-us%2F148282)）** 与 **[2019款 雪佛兰科鲁泽 330T (1.3T)](https://www.google.com/search?q=https%3A%2F%2Fcar.autohome.com.cn%2Fconfig%2Fspec%2F38134.html)（8英寸 MyLink+ 车机，支持有线 CarPlay）** 编写了完整的 iOS 端屏幕镜像桥接代码（`CarPlayMirrorBridge.swift` 与 `Info.plist`）。

在编译部署之前，请先了解苹果 iOS 26.6.1 对 CarPlay 的底层权限限制，以及将任意软件投屏到 19 款科鲁泽车机上的两种落地方案。

## 一、 为什么普通 App 无法直接突破 CarPlay 限制？（必读）

1. **苹果 CarPlay 权限白名单与沙盒隔离**
   根据苹果官方的 [CarPlay Developer Guide](https://www.google.com/search?q=https%3A%2F%2Fdeveloper.apple.com%2Fdownload%2Ffiles%2FCarPlay-Developer-Guide.pdf)，第三方应用想要在车载屏幕上显示图标，必须在签名证书中包含苹果专门审批下发的 Entitlement（如 `com.apple.developer.carplay-maps`），且仅开放给导航、音频、通讯、充电/停车等特定品类。普通个人免费开发者证书无法直接生成可任意绘制画面的 `CPWindow`。
2. **iOS 26 原生“车载视频 (AirPlay Video in the Car)”的局限**
   虽然苹果在 [iOS 26](https://www.google.com/search?q=https%3A%2F%2F9to5mac.com%2F2026%2F05%2F06%2Fcarplay-video-ios-26%2F) 中首次新增了车载 AirPlay 视频功能，但它存在两个硬性门槛（[Merge Screens](https://www.google.com/search?q=https%3A%2F%2Fmergescreens.com%2Fblogs%2Fapple-carplay%2Fcarplay-video-ios-26)）：
   * 仅限挂入 P 挡（驻车状态）且仅支持适配了专属视频权限的流媒体 App，**不支持**全局桌面或任意第三方软件镜像（[Reddit r/CarPlay](https://www.google.com/search?q=https%3A%2F%2Fwww.reddit.com%2Fr%2FCarPlay%2Fcomments%2F1wf0821%2Fhow_ios_2627_carplay_video_actually_works%2F)）。
   * 需要车厂为车机固件升级对应协议，而 **2019款 科鲁泽 1.3T** 的原厂 8 英寸 MyLink+ 车机仅支持标准有线 CarPlay，不支持该新协议。
3. **关于越狱插件 CarBridge 的现状**
   老牌插件 [CarBridge](https://www.google.com/search?q=https%3A%2F%2Fblog.carplayhacks.com%2Fcarbridge%2F) 虽然能接管系统窗口投射任意软件，但目前仅支持到 iOS 16.7.7。您的 **iPhone 16e (A18 芯片 + iOS 26.6.1)** 目前没有任何公开越狱工具或巨魔（TrollStore）漏洞可用（网上声称“iOS 26 免越狱安装 CarBridge”的视频均为诱导下载描述文件的骗局）。

## 二、 本软件工程 (`CarPlayMirrorBridge.swift`) 的编译与部署方法

如果您拥有支持 **CarPlay Maps (`com.apple.developer.carplay-maps`)** 权限的苹果企业/定制开发者证书，可通过以下步骤将本工程编译安装到 iPhone 16e 上：

1. **创建 Xcode 工程**
   * 在 Mac 上打开 Xcode，新建一个 iOS App 工程，Bundle ID 设为 `com.monza.carplay.mirror`。
   * 点击 `File -> New -> Target`，新增一个 **Broadcast Upload Extension**（命名为 `BroadcastUploadExtension`，Bundle ID 为 `com.monza.carplay.mirror.BroadcastUploadExtension`）。
2. **导入代码与配置文件**
   * 将 `CarPlayMirrorBridge.swift` 导入主工程，并将其中 `CarPlayBroadcastSampleHandler` 类勾选关联到 `BroadcastUploadExtension` Target。
   * 使用本工程附带的 `Info.plist` 替换主工程配置（已注册 `CPTemplateApplicationSceneSessionRoleApplication` 车载场景）。
3. **配置签名与权限 (`Signing & Capabilities`)**
   * 为主 App 和 Extension 同时添加 **App Groups**：`group.com.monza.carplay.mirror`。
   * 在主 App 的 `.entitlements` 文件中加入 CarPlay 画布权限：
     ```xml
     <key>com.apple.developer.carplay-maps</key>
     <true/>
     <key>com.apple.security.application-groups</key>
     <array>
         <string>group.com.monza.carplay.mirror</string>
     </array>
     ```
4. **上车连接步骤（19款科鲁泽 1.3T）**
   * 使用 **USB-C 转 USB-A 数据线**（iPhone 16e 为 USB-C 接口，19款科鲁泽扶手箱/中控下方为 USB-A 数据口）连接手机与车机。
   * 在手机端打开「科鲁泽投屏」，点击屏幕广播按钮启动 `ReplayKit` 全局采集，随后退回手机桌面打开任意软件（抖音、B站、高德、浏览器等），画面即通过 `App Group` 实时渲染到科鲁泽 8 英寸车机屏上。

## 三、 针对 19款科鲁泽 1.3T 最省心的免越狱实操替代方案（强烈推荐）

如果您没有特殊权限的苹果企业证书、不想折腾 Xcode 签名，要在 **19款科鲁泽 1.3T** 原厂屏上实现“苹果手机投屏任何软件”，目前最成熟稳定的方案是利用原车有线 CarPlay 通道外接一个 **CarPlay 无线投屏盒 / 安卓 AI Box**：

| 方案类型 | 核心原理（针对 19款科鲁泽 USB 口） | 能否投屏任意软件 | 是否受驻车(P挡)限制 | 触控交互支持 |
| :--- | :--- | :--- | :--- | :--- |
| **CarPlay 无线投屏转接盒**（支持 AirPlay 镜像款） | 插在科鲁泽原车 USB 口伪装成 CarPlay 设备，同时向 iPhone 16e 广播标准 AirPlay 接收端 | 支持（下滑 iPhone 控制中心点「屏幕镜像」，手机显示什么车机就显示什么） | 不受限（行驶中副驾也可看） | 需在手机端操作（镜像模式） |
| **CarPlay 安卓 AI Box 盒子** | 通过科鲁泽原车有线 CarPlay 协议将 8 英寸车机直接变成独立安卓平板，同时内置无线 CarPlay + AirPlay 投屏 | 支持（既能用 iPhone 屏幕镜像投屏，也能直接在车机上装抖音/B站/高德） | 不受限 | 支持直接在科鲁泽 8 英寸触摸屏上点击操作 |
| **自编译 `CarPlayMirrorBridge`** | 利用 ReplayKit 录屏 + CarPlay Maps 画布权限把画面帧绘制到 `CPWindow` | 支持（手机画面实时同步） | 不受限 | 仅顶部比例按钮可点，App 需在手机操作 |
